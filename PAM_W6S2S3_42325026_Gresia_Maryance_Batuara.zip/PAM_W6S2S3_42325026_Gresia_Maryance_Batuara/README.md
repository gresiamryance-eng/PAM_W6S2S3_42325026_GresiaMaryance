# Praktikum PAM W6S2S3 — Navigation and Page Detail

**Mahasiswa:** Gresia Maryance Batuara  
**NIM:** 42325026  
**Program Studi:** D3 Teknologi Informasi — Institut Teknologi Del

## Fitur
- Halaman utama pembelian sayur dengan tab Sayur Box, Sayur Slice, dan Sayur Mayur.
- Kartu produk menampilkan gambar, nama, harga, dan navigasi ke halaman detail.
- Halaman detail menggunakan `Navigator.push` dan tombol kembali dengan `Navigator.pop`.
- Tombol pesan membuka WhatsApp melalui `url_launcher`.
- Layout responsif memakai `flutter_screenutil`.

## Cara menjalankan
1. Ekstrak ZIP ini.
2. Buka folder `PAM_W6S2S3_42325026_Gresia_Maryance_Batuara` di VS Code.
3. Pastikan Flutter SDK sudah terpasang dan emulator/perangkat terdeteksi (`flutter devices`).
4. Jalankan terminal di folder project:
   ```bash
   flutter pub get
   flutter run
   ```
5. Untuk mengganti nomor WhatsApp tujuan, edit nomor `628123456789` di `lib/screens/sayur_detail.dart` dengan nomor toko yang benar (format kode negara tanpa tanda `+`).

## Catatan
Source disusun sebagai implementasi praktikum dari modul W6S2S3. Jalankan `flutter pub get` pada komputer yang memiliki koneksi internet agar dependency terunduh. Project ini belum dapat diklaim sudah diuji di emulator pengguna.
