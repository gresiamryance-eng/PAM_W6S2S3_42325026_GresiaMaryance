import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../models/sayur.dart';
import '../widgets/navbar_widget.dart';
import 'sayur_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }
  @override
  void dispose() { _tabController.dispose(); super.dispose(); }

  final List<Sayur> _sayurs = const [
    Sayur(id: 1, name: 'Bayam', imageUrl: 'assets/images/bayam.png', price: 5000, subMenu: 'Sayur Box'),
    Sayur(id: 2, name: 'Terong', imageUrl: 'assets/images/terong.png', price: 3000, subMenu: 'Sayur Slice'),
    Sayur(id: 3, name: 'Tomat', imageUrl: 'assets/images/tomat.png', price: 3000, subMenu: 'Sayur Mayur'),
    Sayur(id: 4, name: 'Wortel', imageUrl: 'assets/images/wortel.png', price: 4000, subMenu: 'Sayur Box'),
    Sayur(id: 5, name: 'Brokoli', imageUrl: 'assets/images/brokoli.png', price: 6000, subMenu: 'Sayur Slice'),
    Sayur(id: 6, name: 'Paprika', imageUrl: 'assets/images/paprika.png', price: 7000, subMenu: 'Sayur Mayur'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0, centerTitle: true,
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () {}),
        title: Text('Pembelian Sayur', style: TextStyle(fontSize: 21.sp, fontWeight: FontWeight.w600)),
        actions: [IconButton(icon: const Icon(Icons.notifications_none), onPressed: () {})],
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.w),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(height: 14.h),
          Text('List Sayur Segar', style: TextStyle(fontSize: 24.sp, fontWeight: FontWeight.bold, color: const Color(0xFF575E67))),
          SizedBox(height: 8.h),
          TabBar(
            controller: _tabController, isScrollable: true,
            indicatorColor: const Color(0xFFF17532), labelColor: const Color(0xFFC88D67),
            unselectedLabelColor: const Color(0xFF9B9B9B),
            tabs: const [Tab(text: 'Sayur Box'), Tab(text: 'Sayur Slice'), Tab(text: 'Sayur Mayur')],
          ),
          Expanded(child: TabBarView(controller: _tabController, children: [
            SayurPage(sayurs: _sayurs.where((s) => s.subMenu == 'Sayur Box').toList()),
            SayurPage(sayurs: _sayurs.where((s) => s.subMenu == 'Sayur Slice').toList()),
            SayurPage(sayurs: _sayurs.where((s) => s.subMenu == 'Sayur Mayur').toList()),
          ])),
        ]),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Fitur keranjang akan dikembangkan.'))), backgroundColor: const Color(0xFFF17532), child: const Icon(Icons.shopping_bag_outlined, color: Colors.white)),
      bottomNavigationBar: const NavbarWidget(),
    );
  }
}
