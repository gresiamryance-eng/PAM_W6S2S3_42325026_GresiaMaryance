import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/sayur.dart';
import '../widgets/navbar_widget.dart';

class SayurDetail extends StatelessWidget {
  final Sayur sayur;
  const SayurDetail({super.key, required this.sayur});

  Future<void> _orderViaWhatsApp(BuildContext context) async {
    final message = Uri.encodeComponent('Halo, saya mau pesan ${sayur.name} seharga Rp ${sayur.price}. Apakah bisa diantar?');
    final uri = Uri.parse('https://wa.me/628123456789?text=$message');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('WhatsApp tidak dapat dibuka pada perangkat ini.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0, centerTitle: true,
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: Color(0xFF545D68)), onPressed: () => Navigator.of(context).pop()),
        title: Text('Pesan', style: TextStyle(fontSize: 22.sp, color: const Color(0xFF545D68))),
        actions: [IconButton(icon: const Icon(Icons.notifications_none, color: Color(0xFF545D68)), onPressed: () {})],
      ),
      body: ListView(padding: EdgeInsets.symmetric(horizontal: 16.w), children: [
        SizedBox(height: 16.h),
        Text(sayur.subMenu, style: TextStyle(fontSize: 32.sp, fontWeight: FontWeight.bold, color: const Color(0xFFF17532))),
        SizedBox(height: 18.h),
        Hero(tag: sayur.imageUrl, child: Container(height: 230.h, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24.r)), padding: EdgeInsets.all(18.w), child: Image.asset(sayur.imageUrl, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.eco, size: 100, color: Colors.green)))),
        SizedBox(height: 20.h),
        Text('Rp ${sayur.price}', textAlign: TextAlign.center, style: TextStyle(fontSize: 23.sp, fontWeight: FontWeight.bold, color: const Color(0xFFF17532))),
        SizedBox(height: 8.h),
        Text(sayur.name, textAlign: TextAlign.center, style: TextStyle(fontSize: 26.sp, fontWeight: FontWeight.w600, color: const Color(0xFF575E67))),
        SizedBox(height: 14.h),
        Text(sayur.description, textAlign: TextAlign.center, style: TextStyle(fontSize: 15.sp, height: 1.5, color: const Color(0xFF92989A))),
        SizedBox(height: 26.h),
        SizedBox(height: 54.h, child: ElevatedButton.icon(
          onPressed: () => _orderViaWhatsApp(context),
          icon: const Icon(Icons.chat, color: Colors.white), label: const Text('Pesan via WhatsApp', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFF17532), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26.r))),
        )),
        SizedBox(height: 30.h),
      ]),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Fitur keranjang akan dikembangkan.'))), backgroundColor: const Color(0xFFF17532), child: const Icon(Icons.shopping_bag_outlined, color: Colors.white)),
      bottomNavigationBar: const NavbarWidget(),
    );
  }
}
