import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../models/sayur.dart';
import 'sayur_detail.dart';

class SayurPage extends StatelessWidget {
  final List<Sayur> sayurs;
  const SayurPage({super.key, required this.sayurs});

  @override
  Widget build(BuildContext context) {
    if (sayurs.isEmpty) return const Center(child: Text('Belum ada sayuran.'));
    return GridView.builder(
      padding: EdgeInsets.only(top: 12.h, bottom: 22.h),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 10.w, mainAxisSpacing: 10.h, childAspectRatio: .68),
      itemCount: sayurs.length,
      itemBuilder: (context, index) => _buildCard(context, sayurs[index]),
    );
  }

  Widget _buildCard(BuildContext context, Sayur sayur) {
    return InkWell(
      borderRadius: BorderRadius.circular(16.r),
      onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SayurDetail(sayur: sayur))),
      child: Container(
        padding: EdgeInsets.all(10.w),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16.r), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.07), blurRadius: 8, offset: const Offset(0, 3))]),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Align(alignment: Alignment.topRight, child: Icon(sayur.isFavorite ? Icons.favorite : Icons.favorite_border, color: const Color(0xFFEF7532), size: 20.sp)),
          Expanded(child: Hero(tag: sayur.imageUrl, child: Image.asset(sayur.imageUrl, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.eco, size: 64, color: Colors.green)))),
          SizedBox(height: 8.h),
          Text('Rp ${sayur.price}', textAlign: TextAlign.center, style: TextStyle(color: const Color(0xFFCC8053), fontWeight: FontWeight.bold, fontSize: 16.sp)),
          SizedBox(height: 4.h),
          Text(sayur.name, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis, style: TextStyle(color: const Color(0xFF575E67), fontSize: 15.sp, fontWeight: FontWeight.w500)),
          SizedBox(height: 10.h),
          const Divider(height: 1),
          Padding(padding: EdgeInsets.only(top: 8.h), child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.chat_bubble_outline, size: 15.sp, color: const Color(0xFFD17E50)), SizedBox(width: 5.w), Text('Lihat detail', style: TextStyle(color: const Color(0xFFD17E50), fontSize: 12.sp))])),
        ]),
      ),
    );
  }
}
