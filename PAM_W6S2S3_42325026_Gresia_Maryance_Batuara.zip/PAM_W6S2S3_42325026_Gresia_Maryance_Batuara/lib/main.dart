import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'screens/home_page.dart';

void main() => runApp(const SayurMayurApp());

class SayurMayurApp extends StatelessWidget {
  const SayurMayurApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(390, 844),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context, child) => MaterialApp(
        title: 'Sayur Mayur',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          scaffoldBackgroundColor: const Color(0xFFFCFAF8),
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFF17532)),
          fontFamily: 'Roboto',
          appBarTheme: const AppBarTheme(backgroundColor: Colors.white, foregroundColor: Color(0xFF545D68)),
        ),
        home: const HomePage(),
      ),
    );
  }
}
