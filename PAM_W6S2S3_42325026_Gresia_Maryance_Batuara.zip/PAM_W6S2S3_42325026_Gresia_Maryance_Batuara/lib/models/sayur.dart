class Sayur {
  final int id;
  final String name;
  final int price;
  final String imageUrl;
  final bool isFavorite;
  final String subMenu;
  final String description;

  const Sayur({
    required this.id,
    required this.name,
    required this.price,
    required this.imageUrl,
    this.isFavorite = false,
    this.subMenu = 'Sayur Mayur',
    this.description = 'Sayuran segar pilihan dari petani lokal, cocok untuk melengkapi masakan sehari-hari.',
  });
}
