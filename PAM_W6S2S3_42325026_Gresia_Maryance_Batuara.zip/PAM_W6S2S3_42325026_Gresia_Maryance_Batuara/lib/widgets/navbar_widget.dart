import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class NavbarWidget extends StatelessWidget {
  const NavbarWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return BottomAppBar(
      color: Colors.white,
      elevation: 8,
      shape: const CircularNotchedRectangle(),
      notchMargin: 8,
      child: SizedBox(
        height: 48.h,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: const [
            Icon(Icons.home_rounded, color: Color(0xFFEF7532)),
            Icon(Icons.search, color: Color(0xFF676E79)),
            SizedBox(width: 40),
            Icon(Icons.shopping_basket_outlined, color: Color(0xFF676E79)),
            Icon(Icons.person_outline, color: Color(0xFF676E79)),
          ],
        ),
      ),
    );
  }
}
